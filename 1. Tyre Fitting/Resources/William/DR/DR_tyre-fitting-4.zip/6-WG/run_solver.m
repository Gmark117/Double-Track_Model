function [bestP0, Popt] = run_solver(fittingPars, P0, lb, ub, resid_function, tyre_data, fitting)

    %% Figure out how many times we have to execute fmincon
    n_iterations = 1;
    fvalMin = Inf;  % Initialize cost function at optimal value
    bestP0 = P0;    % Save best initial guess
    Popt = P0;      % Initialize optimal parameters
    
    if fitting.Randomizer_Active
        n_iterations = fitting.Randomizer_Niter;
    end
    
    for k = 1:n_iterations
        % Initialize solver options
        options = optimoptions('fmincon');
        
        %% Compute initial guess if required
        if fitting.Randomizer_Active
            [P0, options] = randomize_fmincon(P0, lb, ub);
            disp(['Progress: ',num2str(k), ' / ', num2str(n_iterations)]); 
        end
        
        for i = 1:length(fittingPars)
            tyre_data.(fittingPars{i}) = P0(i);
        end
        
        % LSM_pure_Fx returns the residual, so minimize the residual varying X. It
        % is an unconstrained minimization problem
        % cost_function = @(P) resid_MF96_FY(fittingPars, P, FY, KAPPA, ALPHA, GAMMA , FZ, tyre_data);
        cost_function = @(P) resid_function(P, tyre_data);
        
        if fitting.Display
            options = optimoptions('fmincon','Display','iter');
        end
        [Piter,fval,exitflag] = fmincon(cost_function,P0,[],[],[],[],lb,ub,[],options);
        
        if fval < fvalMin
            fval = fvalMin;
            bestP0 = P0;
            Popt = Piter;
        end 
    end   