%% Initialisation
if exist('RUN_EVERYTHING_FLAG','var') == 0
    clc
    clearvars 
    close all   
    addpath('tyre_lib')
    addpath('dataset')
    addpath('log')
    addpath('tables')
    addpath('figures')
end

%% load data
% Select dataset 
if exist('wheel','var') == 0
    wheel = 'rear';
end
if exist('direction', 'var') == 0
    direction = 'lateral';
end

filename = strcat('dataset/',wheel,'_',direction,'_dataset.mat');
data = load(filename);
tablename = fieldnames(data);
table = data.(tablename{1});

% Remove zeros
table = table(table.FZ ~= 0,:); % Remove all entries in which Fz = 0

%% Create subtables in which some parameter is kept at a constant value
create_subtables

%% Select velocity
% Is the stifness decreasing (due to increase in temperature) when we
% increase Vx?

if exist('vxSelected', 'var') == 0
    vxSelected = '45';
end

VX = [];
switch vxSelected
    case '5'
        VX = VX_05;
    case '20'
        VX = VX_20;
    case '45'
        VX = VX_45;
    case '90'
        VX = VX_90;
end

%% Plot raw data
plot_setup
% plot_raw_data

%% FITTING 
% Fitting Options
fitting.Dataset = strcat(wheel,'_',direction);
fitting.Display = false;
fitting.Log = true;
fitting.VX = str2num(vxSelected);
fitting.Wheel = wheel;
fitting.showPlot = false;

% Tyre structure data initialization
[tyre_data] = initialize_tyre_data();
tyre_data.Fz0 = 4500;  
tyre_data.R0 = 0.327;   

% Fitting
if strcmp(direction,'longitudinal')
    longitudinal_fitting;
    longitudinal_plot;
else strcmp(direction,'lateral')
    lateral_fitting;
    lateral_plot;
    moment_fitting;
    moment_plot;
end
