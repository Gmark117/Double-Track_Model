% Pure alignment moment MZ0
% This function remap the scalar function to its vectorial form
function [mz0_vec] = MF96_MZ0_vec(kappa_vec, alpha_vec, phi_vec, Fz_vec, tyre_data)
  n_pts = length(alpha_vec);
  mz0_vec = zeros(size(alpha_vec));
  
  for i = 1:n_pts
    mz0_vec(i) = MF96_MZ0(kappa_vec(i), alpha_vec(i), phi_vec(i), Fz_vec(i), tyre_data);
  end
  
 end
