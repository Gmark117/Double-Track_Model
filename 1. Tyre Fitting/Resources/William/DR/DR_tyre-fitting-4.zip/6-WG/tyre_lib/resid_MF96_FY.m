function res = resid_MF96_FY(fittingPars, P, FY, KAPPA, ALPHA, GAMMA , FZ, tyre_data)
    % ----------------------------------------------------------------------
    %% Compute the residuals - least squares approach - to fit the Fx curve 
    %   Pacejka 1996 Magic Formula
    % ----------------------------------------------------------------------

    % Define MF coefficients
    tmp_tyre_data = tyre_data;
    for i = 1:length(fittingPars)
        tmp_tyre_data.(fittingPars{i}) = P(i);
    end 
    
    % Lateral Force (Combined Slip) Equations
    res = 0;
    for i=1:length(ALPHA)
       fy  = MF96_FY(KAPPA(i), ALPHA(i), GAMMA(i), FZ(i), tmp_tyre_data);
       res = res+(fy-FY(i))^2;
    end
    
    % Compute the residuals
    res = res/sum(FY.^2);

end

