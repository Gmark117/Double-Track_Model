function res = resid_MF96_FX(fittingPars, P, FX, KAPPA, ALPHA, GAMMA , FZ, tyre_data)
    % ----------------------------------------------------------------------
    %% Compute the residuals - least squares approach - to fit the Fx curve 
    %   Pacejka 1996 Magic Formula
    % ----------------------------------------------------------------------

    % Define MF coefficients
    tmp_tyre_data = tyre_data;
    for i = 1:length(fittingPars)
        tmp_tyre_data.(fittingPars{i}) = P(i);
    end 
    
    % Longitudinal Force (Pure Longitudinal Slip) Equations
    res = 0;
    for i=1:length(KAPPA)
       fx  = MF96_FX(KAPPA(i), ALPHA(i), GAMMA(i), FZ(i), tmp_tyre_data);
       res = res+(fx-FX(i))^2;
    end
    
    % Compute the residuals
    res = res/sum(FX.^2);

end

