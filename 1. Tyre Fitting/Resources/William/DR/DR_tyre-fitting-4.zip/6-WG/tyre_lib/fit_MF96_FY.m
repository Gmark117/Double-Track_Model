function [tyre_data] = fit_MF96_FY(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting)

    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FY = -TDataSub.FY;

    %% Run optimizer tool
    resid_function = @(P, tyre_data) resid_MF96_FY(fittingPars, P, FY, KAPPA, ALPHA, GAMMA , FZ, tyre_data);
    [bestP0, Popt] = run_solver(fittingPars, P0, lb, ub, resid_function, tyre_data, fitting);
    
    %% Display results
    % Display results that would be obtained with initial guess
    for i = 1:length(fittingPars)
        tyre_data.(fittingPars{i}) = bestP0(i);
    end
    FY_guess = MF96_FY_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    
    % Copy the results obtained with minimization
    for i = 1:length(fittingPars)
        tyre_data.(fittingPars{i}) = Popt(i);
    end
    % Recompute force and residues with optimal parameters
    FY_opt = MF96_FY_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);  
 
    % Plot graph with raw data/ initial guess solution/ optimal solution
    if fitting.showPlot
        plot_selected_data(TDataSub, fitting.textDescription)
        figure()
        plot(ALPHA,FY,'o', 'DisplayName', 'dataset')
        hold on
        plot(ALPHA,FY_guess,'gx', 'DisplayName', 'guess')
        hold on
        plot(ALPHA,FY_opt,'r*', 'DisplayName', 'opt')
        legend
        ylabel('FY (N)')
        xlabel('Slip angle')
    end
    
    % R-squared is 
    % 1-SSE/SST
    % SSE/SST = res_Fx0_nom
    % SSE is the sum of squared error,  SST is the sum of squared total
    res_opt = resid_MF96_FY(fittingPars, Popt, FY, KAPPA, ALPHA, GAMMA , FZ, tyre_data);
    r_squared = 1-res_opt;
    disp(['Lower boundary: ', num2str(lb  ,"%.3f     ")])
    disp(['Upper boundary: ', num2str(ub  ,"%.3f     ")])
    disp(['Optimal sol:    ', num2str(Popt,"%.3f     ")])
    fprintf('R-squared = %6.3f\n',r_squared);
    
    % Write table
    write_table(fittingPars, tyre_data, r_squared, [], fitting)
    
    % Save data into log file
    if fitting.Log
        datasetName = fitting.Dataset; 
        logfileName = strcat('log/', datasetName, '/', mfilename, '/', datestr(now,'HH-MM-SS__mm-dd-yyyy'), '.mat');
        save(logfileName,'fittingPars','r_squared','lb','ub','bestP0','Popt','tyre_data')
    end