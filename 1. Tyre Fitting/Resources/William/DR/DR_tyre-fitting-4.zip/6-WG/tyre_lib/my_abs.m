function [xabs] = my_abs(x)
   xabs = abs(x);
end