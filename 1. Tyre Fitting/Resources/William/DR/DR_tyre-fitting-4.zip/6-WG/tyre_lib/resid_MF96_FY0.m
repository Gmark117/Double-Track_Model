function res = resid_MF96_FY0(fittingPars, P, FY, KAPPA, ALPHA, GAMMA , FZ, tyre_data)
    % ----------------------------------------------------------------------
    %% Compute the residuals - least squares approach - to fit the Fx curve 
    %   Pacejka 1996 Magic Formula
    % ----------------------------------------------------------------------

    % Define MF coefficients
    tmp_tyre_data = tyre_data;
    for i = 1:length(fittingPars)
        tmp_tyre_data.(fittingPars{i}) = P(i);
    end 
    
    % Lateral Force (Pure Lateral Slip) Equations
    res = 0;
    for i=1:length(ALPHA)
       fy0  = MF96_FY0(KAPPA(i), ALPHA(i), GAMMA(i), FZ(i), tmp_tyre_data);
       res = res+(fy0-FY(i))^2;
    end
    
    % Compute the residuals
    res = res/sum(FY.^2);

end

