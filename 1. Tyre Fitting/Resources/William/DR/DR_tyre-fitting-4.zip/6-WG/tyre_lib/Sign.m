function res = Sign(x)
  
   res = x./sqrt(x.^2+1e-6);
  
end