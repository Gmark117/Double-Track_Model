% Pure longitudinal force FX0
% This function remap the scalar function to its vectorial form
function [fx0_vec] = MF96_FX0_vec(kappa_vec, alpha_vec, phi_vec, Fz_vec, tyre_data)
  n_pts = length(kappa_vec);
  fx0_vec = zeros(size(kappa_vec));
  
  for i = 1:n_pts
   % precode
   [kappa__x, Bx, Cx, Dx, Ex, SVx] = MF96_FX0_coeffs(kappa_vec(i), alpha_vec(i), phi_vec(i), Fz_vec(i), tyre_data);
   % main code
    fx0_vec(i) = magic_formula(kappa__x, Bx, Cx, Dx, Ex, SVx);
  end
  
 end
