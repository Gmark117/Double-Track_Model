%% STEP 1 Fitting with Fz = Fz$_0$ and $\gamma$=0, $\alpha$ = 0
fittingPars = {'pCx1';'pDx1';'pEx1';'pEx4';'pHx1';'pKx1';'pVx1'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData( ALPHA_00, GAMMA_00, VX, FZ_4500);

% Define limits  for parameters to be optimised
% 1< pCx1 < 2 
% 0< pEx1 < 1 
lb = [1, 0.01, -1, -1, -1,  0, -1];
ub = [2, 10,    1 , 1,  1,1e2,  1];
% Initial guess
P0 = [2,2,1,0.1,0.1,70,0.1];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = '$F_z$ = $F_{z0}$, $\gamma$=0, $\alpha$ = 0'; 
fitting.textFileModel = 'tables/HorizontalModel_1.txt';
fitting.textFileOutput= 'tables/HorizontalOut_1.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FX0(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

% Print results
[kappa__x, Bx, Cx, Dx, Ex, SVx] = MF96_FX0_coeffs(0, 0, 0, tyre_data.Fz0, tyre_data);
fprintf('Bx      = %6.3f\n',Bx);
fprintf('Cx      = %6.3f\n',Cx);
fprintf('Dx      = %6.3f\n',Dx);
fprintf('Ex      = %6.3f\n',Ex);
fprintf('SVx     = %6.3f\n',SVx);
fprintf('kappa_x = %6.3f\n',kappa__x);
fprintf('Kx      = %6.3f\n',Bx*Cx*Dx/tyre_data.Fz0);

%% STEP 2 Variable $F_z$, $\gamma$=0, $\alpha$ = 0

fittingPars = {'pDx2';'pEx2';'pEx3';'pKx2';'pKx3';'pHx2';'pVx2'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData( ALPHA_00, GAMMA_00, VX);

% % Define limits  for parameters to be optimised
lb = [-1, -1, -1, -100, -10, -1, -1];
ub = [ 0,  1,  1,  100,  10,  1,  1];
% % Initial guess
P0 = [-0.1,0,0,0,0,0,0];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'variable $F_z$, $\gamma$=0, $\alpha$ = 0'; 
fitting.textFileModel = 'tables/HorizontalModel_2.txt';
fitting.textFileOutput= 'tables/HorizontalOut_2.txt';
 
% Run optimization algorithm
[tyre_data] = fit_MF96_FX0(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

%% STEP3 Fitting with Fz variable and alpha = 0
fittingPars = {'pDx3'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(ALPHA_00, VX);

% % Define limits  for parameters to be optimised
lb = [-5];
ub = [ 5];
% % Initial guess
P0 = 2.5;

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'variable $F_z$, variable $\gamma$, $\alpha$ = 0'; 
fitting.textFileModel = 'tables/HorizontalModel_3.txt';
fitting.textFileOutput= 'tables/HorizontalOut_3.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FX0(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

%% STEP4 Fitting combined case
fittingPars = {'rBx1'; 'rBx2'; 'rCx1'; 'rHx1'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = VX;

% Define limits  for parameters to be optimised
lb = [ 0, -100, 0, -1];
ub = [10,  100, 2,  1];
% % Initial guess
P0 = [3.5, 21.2, 1.13, -0.00170379];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'combined case'; 
fitting.textFileModel = 'tables/HorizontalModel_4.txt';
fitting.textFileOutput= 'tables/HorizontalOut_4.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FX(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);
