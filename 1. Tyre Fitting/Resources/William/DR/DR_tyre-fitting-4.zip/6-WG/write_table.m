function write_table(fittingPars, tyre_data, r_squared, rmse, fitting)
    if ~isfile(fitting.textFileOutput)
        copyfile(fitting.textFileModel,fitting.textFileOutput)
    end

    fileText = readlines(fitting.textFileOutput);
    fileText = strrep(fileText,"VAL\_test\_description",fitting.textDescription);
    % Get speed in which test was performed
    textVX = num2str(fitting.VX);
    % Get wheel pos (rear/front)
    wheel = strtok(fitting.Dataset,'_');
    textWheel = upper(wheel);
    n_params = length(fittingPars);
    for i = 1:n_params
        fileText = strrep(  fileText, ...
                            strcat("VAL\_",textWheel,"\_VX",textVX,"\_",fittingPars{i}), ...
                            num2str(1+tyre_data.(fittingPars{i})));
    end
    % TODO: Modify RMSE
    fileText = strrep(fileText,strcat("VAL\_",textWheel,"\_VX",textVX,"\_","RMSE"),num2str(0));
    fileText = strrep(fileText,strcat("VAL\_",textWheel,"\_VX",textVX,"\_","R2"),num2str(r_squared));

    % Append a space in the beginning of each string to create correctly
    % the LaTeX file
    for line_idx = 1:length(fileText)
        fileText(line_idx) = append(" ",fileText(line_idx));
    end
    
    fid = fopen(fitting.textFileOutput,'wt'); 
    fprintf(fid, '%s', fileText) ;
    fclose(fid);
    
    