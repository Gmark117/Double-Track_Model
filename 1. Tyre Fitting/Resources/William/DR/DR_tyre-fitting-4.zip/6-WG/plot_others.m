%% 
% Plot ALPHA vs FY, with variable GAMMA
[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_00, VX);
tab = TDataSub;
plot(tab.ALPHA, -tab.FY, 'x');
hold on

[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_25, VX);
tab = TDataSub;
plot(tab.ALPHA, -tab.FY, 'x');
hold on

[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_50, VX);
tab = TDataSub;
plot(tab.ALPHA, -tab.FY, 'x');
hold on

%%
[TDataSub, ~] = intersectTableData(VX, ALPHA_00);
tab = TDataSub;
plot(tab.KAPPA, tab.FX, 'x');
hold on

[TDataSub, ~] = intersectTableData(VX, ALPHA_50);
tab = TDataSub;
plot(tab.KAPPA, tab.FX, 'x');
hold on

[TDataSub, ~] = intersectTableData(VX, ALPHA_100);
tab = TDataSub;
plot(tab.KAPPA, tab.FX, 'x');
hold on

