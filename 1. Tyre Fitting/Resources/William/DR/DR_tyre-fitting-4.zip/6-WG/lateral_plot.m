%% Plot figures that are suggested on Lecture-02-5-DCVR-Tyre

% Setup
close all
currentFolder = strcat('figures/Fy/',wheel,'/','VX_',vxSelected);
mkdir(currentFolder);

colors = {'#0072BD','#D95319','#EDB120','#7E2F8E','#77AC30','#4DBEEE'};
% Nominal load
FZ_NOM = FZ_4500;
FZ_NOM_VAL = 4500;

%% a)
figure
hold on
titleText = strcat('Pure lateral slip --   $F_z:=$   ',' $F_{z0}$ ,',...
                                           ' $\kappa$ ',' $=0$ ,', ...
                                           ' $\gamma$ ',' $=0$ ');
title(titleText, 'interpreter', 'Latex');
xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$F_y$ (N)','interpreter', 'Latex')
[TDataSub, ~] = intersectTableData( KAPPA_00, GAMMA_00, VX, FZ_NOM);
KAPPA = TDataSub.KAPPA;
ALPHA = TDataSub.ALPHA;
GAMMA = TDataSub.GAMMA;
FZ = TDataSub.FZ;
FY = -TDataSub.FY;   
[fy0_fit] = MF96_FY0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
plot(ALPHA, fy0_fit, 'DisplayName', 'Fitted');
plot(ALPHA, FY, '.', 'DisplayName', 'Raw');
legend
grid on
exportgraphics(gcf,strcat(currentFolder,'/FY_figA.png'),'Resolution',ExportFigResolution)

%% b)
figure
hold on
titleText = strcat('Pure lateral slip at different vertical loads -- ');
title(titleText, 'interpreter', 'Latex');
xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$F_y$ (N)','interpreter', 'Latex')

vertLoads_TXT = [  2500,    4500,    6500,   10000];
vertLoads =     { FZ_2500, FZ_4500, FZ_6500, FZ_10000};

for i = 1:length(vertLoads)
    [TDataSub, ~] = intersectTableData( KAPPA_00, GAMMA_00, VX, vertLoads{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FY = -TDataSub.FY;  
    [fy0_fit] = MF96_FY0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(ALPHA, fy0_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted Fz = ',num2str(vertLoads_TXT(i)), ' N'));
    plot(ALPHA, FY, '*', 'color', colors{i} , ...
        'DisplayName', strcat('Raw Fz = ',num2str(vertLoads_TXT(i)), ' N'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FY_figB.png'),'Resolution',ExportFigResolution)

%% c)
kappa_values = linspace(min(table.KAPPA),max(table.KAPPA),1000);
alpha_values = deg2rad([  0,        2.5,       5.0,      7.5,      10.0]);

figure
hold on
titleText = strcat('Weighting function G$_{y\kappa}$ as a function of $\kappa$ -- ', ...
                                            ' $F_z:=$   ',' $F_{z0}$ ,',...
                                            ' $\gamma$ ',' $=0$ ,');                                        
title(titleText, 'interpreter', 'Latex');
xlabel('longitudinal slip $\kappa$','interpreter', 'Latex')
ylabel('G$_{y\kappa}$','interpreter', 'Latex')

for i = 1:length(alpha_values)
    gyk_fit = [];
    for k = 1:length(kappa_values)
        [Gxa, Gyk, SVyk] = MF96_FXcomb_coeffs(kappa_values(k), alpha_values(i), 0, FZ_NOM_VAL, tyre_data);
        gyk_fit = [gyk_fit, Gyk];
    end
    plot(kappa_values, gyk_fit, 'color', colors{i} ,...
        'DisplayName', strcat('$\alpha = $ ',num2str(alpha_values(i)), ' deg'));
end
legend('location','northeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FY_figC.png'),'Resolution',ExportFigResolution)

%% d)
figure
hold on
titleText = strcat('Pure lateral slip at different cambers -- ', ...
                    ' $F_z=$   ',' $F_{z0}$ ,',...
                    ' $\kappa$ ',' $=0$');   
title(titleText, 'interpreter', 'Latex');
xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$F_y$ (N)','interpreter', 'Latex')

camber_TXT =     [  0,    2.5,    5, ];
camber_ANGLES =  { GAMMA_00, GAMMA_25, GAMMA_50};

for i = 1:length(camber_ANGLES)
    [TDataSub, ~] = intersectTableData( KAPPA_00, FZ_NOM, VX, camber_ANGLES{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FY = -TDataSub.FY;   
    [fy0_fit] = MF96_FY0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(ALPHA, fy0_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted $\gamma$ = ',num2str(camber_TXT(i)), ' deg'));
    plot(ALPHA, FY, 'o', 'color', colors{i} , ...
        'DisplayName', strcat('Raw $\gamma$ = ',num2str(camber_TXT(i)), ' deg'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FY_figD.png'),'Resolution',ExportFigResolution)

%% e)
figure
hold on
titleText = strcat('Combined lateral slip at variable longidutinal slip -- ', ...
                    ' $F_{z} = $   ',' $ F_{z0}$ ,',...
                    ' $\gamma $ ',' $ =0$');   
title(titleText, 'interpreter', 'Latex');
xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$F_y$ (N)','interpreter', 'Latex')

kappa_TXT =   [  0,   0.05 ,    0.1,    0.15,   0.20  ];
kappa_VALS =  { KAPPA_00, KAPPA_05, KAPPA_10, KAPPA_15, KAPPA_20};

for i = 1:length(kappa_VALS)
    [TDataSub, ~] = intersectTableData(GAMMA_00, FZ_NOM, VX, kappa_VALS{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FY = -TDataSub.FY;   
    [fy_fit] = MF96_FY_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(ALPHA, fy_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted $\kappa$ = ',num2str(kappa_TXT(i))));
    plot(ALPHA, FY, '.', 'color', colors{i} , ...
        'DisplayName', strcat('Raw $\kappa$ = ',num2str(kappa_TXT(i))));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FY_figE.png'),'Resolution',ExportFigResolution)

%% f)
kappa_values = [0, 0.05, 0.1, 0.15, 0.2];
alpha_values = (linspace(min(table.ALPHA),max(table.ALPHA),100));

figure
hold on
titleText = strcat('Weighting function G$_{y\kappa}$ as a function of $\alpha$ --', ...
                                            ' $F_z:=$   ',' $F_{z0}$ ,',...
                                            ' $\gamma$ ',' $=0$ ,');                                        
title(titleText, 'interpreter', 'Latex');
xlabel('side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('G$_{y\kappa}$','interpreter', 'Latex')

for i = 1:length(kappa_values)
    gyk_fit = [];
    for k = 1:length(alpha_values)
        [Gxa, Gyk, SVyk] = MF96_FXcomb_coeffs(kappa_values(i), alpha_values(k), 0, FZ_NOM_VAL , tyre_data);
        gyk_fit = [gyk_fit, Gyk];
    end
    plot(rad2deg(alpha_values), gyk_fit, 'color', colors{i} ,...
        'DisplayName', strcat('$\kappa = $ ',num2str(kappa_values(i))));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FY_figF.png'),'Resolution',ExportFigResolution)
