function [P0, optSolver] = randomize_fmincon(init_guess, lb, ub)
    DEFAULT_RANGE = 10000;
    
    % Compute number of parameters to generate
    n_params = length(init_guess);
    P0 = zeros(1,n_params);

    for i=1:n_params
        % Initialize bounds
        bounds = [0,0];
        % Initialize lower bound
        if(isempty(lb))
            bounds(1) = DEFAULT_RANGE*randn(1);
        else
            bounds(1) = lb(i);
        end
        % Initialize upper bound
        if(isempty(ub))
            bounds(2) = DEFAULT_RANGE*randn(1);
        else
            bounds(2) = ub(i);
        end
        % Reorder to assure it's in the form [min,max]
        bounds = sort(bounds);
        % Compute a randon number within the bounds
        P0(i) = bounds(1) + rand(1)*(bounds(2) - bounds(1));     
    end
    
    % Choose randomically the numerical algorithm
    alg_idx = randi(3,1);
    algorithmName = 'interior-point';
%     if alg_idx == 1
%         algorithmName = 'interior-point';
%     elseif alg_idx == 2
%         algorithmName = 'active-set';
%     else
%         algorithmName = 'sqp';
%     end
   optSolver = optimoptions('fmincon', 'Algorithm', algorithmName);
   
    
    
    
    