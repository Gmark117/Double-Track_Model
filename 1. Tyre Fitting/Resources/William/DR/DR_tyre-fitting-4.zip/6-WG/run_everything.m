%% Initialisation
clc
clearvars
close all   
addpath('tyre_lib')
addpath('dataset')
addpath('log')
addpath('tables')
addpath('figures')

% Start timer
tic 

% Remove all old tables with old results
delete('tables\*Out_*.txt');
delete('tables\*Out_*.tex');

% Select dataset 
RUN_EVERYTHING_FLAG = true;
wheelList = {'rear', 'front'};
directionList = {'lateral','longitudinal'};
vxList = {'5', '20', '45', '90'};

% Number of operations: used for progress display
totalOps = length(wheelList)*length(directionList)*length(vxList);

for ii = 1:length(wheelList)
    for jj=1:length(directionList)
        for kk=1:length(vxList)
            nOps = (kk-1)+(jj-1)*length(vxList)+(ii-1)*length(directionList)*length(vxList);
            disp("*****************************************")
            disp("***************PROGRESS******************");
            disp(strcat("            ",...
                 num2str(nOps*100.0/totalOps),...
                 " %                 "));
            disp("*****************************************");
            wheel = wheelList{ii};
            direction = directionList{jj};
            vxSelected = vxList{kk};
            main_tyre_data_analysis;
        end
    end
end

% Rename all files with .tex extension
listOutTables = dir('tables/*Out*');
for i = 1:length(listOutTables)
    nametxt = listOutTables(i).name;
    nametex = strrep(nametxt,'.txt','.tex');
    copyfile(strcat('tables/',nametxt),strcat('tables/',nametex));
end

% Print elapsed time
toc

% Remove flag
clear RUN_EVERYTHING_FLAG