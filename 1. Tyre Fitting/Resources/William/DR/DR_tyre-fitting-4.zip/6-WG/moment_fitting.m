%% Fitting with Fz = $Fz_0$ and $\gamma$=0, $\kappa$ = 0
fittingPars = {'qHz1';'qBz1';'qCz1';'qDz1';'qEz1';'qEz4'; ...
                'qBz9'; 'qBz10'; 'qDz6'}; 
% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_00, VX, FZ_4500);

% Define limits  for parameters to be optimised
lb = [-1, 9, 1,   0 ,1 ,-0.1,-1000,-1000, 0];
ub = [ 1,20, 3, 0.2, 2 , 1 ,  1000, 1000, 1];

% Initial guess
P0_0 = [0.000, 10, 2, 0.1, 1.5, 0.000, -500, -500, 0.1];
%P0_0 = [-0.001, 1, 1, 0.1, -1, 0.1, 30, 0.1, -0.5];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = '$F_z = F_{z0}$ and $\gamma$=0, $\kappa$ = 0'; 
fitting.textFileModel = 'tables/MomentModel_1.txt';
fitting.textFileOutput= 'tables/MomentOut_1.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_MZ0(fittingPars, P0_0, lb, ub, TDataSub, tyre_data, fitting);

% Print results
[alpha__t, alpha__r, Bt, Ct, Dt, Et, Br, Dr] = MF96_MZ0_coeffs(0, 0, 0, tyre_data.Fz0, tyre_data);
fprintf('alpha__t      = %6.3f\n',alpha__t);
fprintf('alpha__r      = %6.3f\n',alpha__r);
fprintf('Bt      = %6.3f\n',Bt);
fprintf('Ct      = %6.3f\n',Ct);
fprintf('Dt      = %6.3f\n',Dt);
fprintf('Et      = %6.3f\n',Et);
fprintf('Br      = %6.3f\n',Br);
fprintf('Dr      = %6.3f\n',Dr);

%% Fitting with variable $F_z$, $\gamma$=0, $\kappa$ = 0; 
fittingPars = {'qHz2';'qBz2';'qBz3';'qDz2';'qEz2';'qEz3';'qDz7'}; 

%  Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_00, VX);

% Define limits  for parameters to be optimised
lb = [];
ub = [];
% Initial guess
%P0_1 = [-0.01,-0.01,-0.01,-0.01,-0.01,-0.01,-0.01];
P0_1 = [0.0001, -2, -0.5, 0.005, 0.01, -0.005, -0.001];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'variable $F_z$, $\gamma$=0, $\kappa$ = 0'; 
fitting.textFileModel = 'tables/MomentModel_2.txt';
fitting.textFileOutput= 'tables/MomentOut_2.txt';

[tyre_data] = fit_MF96_MZ0(fittingPars, P0_1, lb, ub, TDataSub, tyre_data, fitting);

%% Fitting with variable $F_z$, variable $\gamma$
fittingPars = {'qHz3';'qHz4';'qBz4';'qBz5';'qDz3';'qDz4';'qEz5';'qDz8';'qDz9'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(KAPPA_00, VX);

% Define limits  for parameters to be optimised
% Initial guess
P0_2 = [-0.01,-0.01,0.01,0.01,-0.01,10,-0.01,-0.01,-0.01];

lb = [];
ub = [];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'variable $F_z$, variable $\gamma$'; 
fitting.textFileModel = 'tables/MomentModel_3.txt';
fitting.textFileOutput= 'tables/MomentOut_3.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_MZ0(fittingPars, P0_2, lb, ub, TDataSub, tyre_data, fitting);