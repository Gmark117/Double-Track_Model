%% Plot figures that are suggested on Lecture-02-5-DCVR-Tyre

% Setup
close all
currentFolder = strcat('figures/Mz/',wheel,'/','VX_',vxSelected);
mkdir(currentFolder);
colors = {'#0072BD','#D95319','#EDB120','#7E2F8E','#77AC30','#4DBEEE'};

% Nominal load
FZ_NOM = FZ_4500;
FZ_NOM_VAL = 4500;

%% a)
figure
hold on
titleText = strcat('Alignment Moment     --   $F_z:=$   ',' $F_{z0}$ ,',...
                                              ' $\kappa$ ',' $=0$ ,', ...
                                              ' $\gamma$ ',' $=0$ ,');

xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$M_z$ (N.m)','interpreter', 'Latex')
[TDataSub, ~] = intersectTableData( KAPPA_00, GAMMA_00, VX, FZ_NOM);
KAPPA = TDataSub.KAPPA;
ALPHA = TDataSub.ALPHA;
GAMMA = TDataSub.GAMMA;
FZ = TDataSub.FZ;
MZ = -TDataSub.MZ;   
[mz0_fit] = MF96_MZ0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
plot(ALPHA, mz0_fit, 'DisplayName', 'Fitted');
plot(ALPHA, MZ, '.', 'DisplayName', 'Raw');
legend
grid on
exportgraphics(gcf,strcat(currentFolder,'/MY_figA.png'),'Resolution',ExportFigResolution)

%% b)
figure
hold on
titleText = strcat('Alignment Moment at different vertical loads -- ');
title(titleText, 'interpreter', 'Latex');
xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$M_z$ (N.m)','interpreter', 'Latex')

vertLoads_TXT = [  2500,    4500,    6500,   10000];
vertLoads =     { FZ_2500, FZ_4500, FZ_6500, FZ_10000};

for i = 1:length(vertLoads)
    [TDataSub, ~] = intersectTableData( KAPPA_00, GAMMA_00, VX, vertLoads{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    MZ = -TDataSub.MZ;   
    [mz0_fit] = MF96_MZ0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(ALPHA, mz0_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted Fz = ',num2str(vertLoads_TXT(i)), ' N'));
    plot(ALPHA, MZ, '*', 'color', colors{i} , ...
        'DisplayName', strcat('Raw Fz = ',num2str(vertLoads_TXT(i)), ' N'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/MY_figB.png'),'Resolution',ExportFigResolution)

%% c)
figure
hold on
titleText = strcat('Alignment moment at different cambers -- ', ...
                    ' $F_z=$   ',' $F_{z0}$ ,',...
                    ' $\kappa$ ',' $=0$');   
title(titleText, 'interpreter', 'Latex');
xlabel('Side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('$M_z$ (N.m)','interpreter', 'Latex')

camber_TXT =     [  0,    2.5,    5, ];
camber_ANGLES =  { GAMMA_00, GAMMA_25, GAMMA_50};

for i = 1:length(camber_ANGLES)
    [TDataSub, ~] = intersectTableData( KAPPA_00, FZ_NOM, VX, camber_ANGLES{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    MZ = -TDataSub.MZ;  
    [mz0_fit] = MF96_MZ0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(ALPHA, mz0_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted $\gamma$ = ',num2str(camber_TXT(i)), ' deg'));
    plot(ALPHA, MZ, '*', 'color', colors{i} , ...
        'DisplayName', strcat('Raw $\gamma$ = ',num2str(camber_TXT(i)), ' deg'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/MY_figC.png'),'Resolution',ExportFigResolution)