%% STEP 1 Fitting with Fz = Fz_nom and camber=0, kappa = 0
fittingPars = {'pCy1';'pDy1';'pEy1';'pHy1';'pKy1';'pKy2';'pVy1'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_00, VX, FZ_4500);

% Define limits  for parameters to be optimised
lb = [1, 0.01, -1, -1, -1,  0, -1];
ub = [2, 10,    1 , 1,100, 10,  1];

% Initial guess
P0 = [2,2,1,0.1,100,70,0.1];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = '$F_z$ = $F_{z0}$, $\gamma$=0, $\kappa$ = 0'; 
fitting.textFileModel = 'tables/LateralModel_1.txt';
fitting.textFileOutput= 'tables/LateralOut_1.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FY0(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

% Print results
[alpha__y, By, Cy, Dy, Ey, SVy] = MF96_FY0_coeffs(0, 0, 0, tyre_data.Fz0, tyre_data);
fprintf('By      = %6.3f\n',By);
fprintf('Cy      = %6.3f\n',Cy);
fprintf('Ey      = %6.3f\n',Ey);
fprintf('SVy     = %6.3f\n',SVy);
fprintf('alpha_y = %6.3f\n',alpha__y);
fprintf('Ky      = %6.3f\n',By*Cy*Dy/tyre_data.Fz0);

%% STEP 2 Fitting with Fz variable and camber = 0, kappa = 0
fittingPars = {'pDy2', 'pEy2', 'pHy2', 'pVy2'}; 
%  Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(KAPPA_00, GAMMA_00, VX);

% Define limits  for parameters to be optimised
lb = [-1, -1, -1, -1];
ub = [ 1,  10,  1,  1];
% Initial guess
P0 = [0.5,5,0.1,0.1];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'variable $F_z$, $\gamma$=0, $\kappa$ = 0'; 
fitting.textFileModel = 'tables/LateralModel_2.txt';
fitting.textFileOutput= 'tables/LateralOut_2.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FY0(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

%% STEP 3 Fitting with Fz variable and gamma variable
fittingPars = {'pDy3', 'pEy3', 'pEy4', 'pHy3', 'pKy3', 'pVy3', 'pVy4'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(KAPPA_00, VX);

% Define limits  for parameters to be optimised
lb = [-10, -1, -20, -2, -2, -10, -1];
ub = [ 10,  1,  20,  2,  2,  10,  1];
% Initial guess
P0 = [10,0,10,0.25,0,1,1];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'variable $F_z$, variable $\gamma$, $\kappa$ = 0'; 
fitting.textFileModel = 'tables/LateralModel_3.txt';
fitting.textFileOutput= 'tables/LateralOut_3.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FY0(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

%% STEP 4.1 Fitting combined case - $F_z$ = $F_{z0}$ , $\gamma=0$
fittingPars = {'rBy1', 'rBy2', 'rBy3', 'rCy1', 'rHy1', 'rVy1', 'rVy4', 'rVy5', 'rVy6'};
%fittingPars = {'rBx1'; 'rBx2'; 'rCx1'; 'rHx1'}; 

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(VX, GAMMA_00, FZ_4500);

% % Define limits  for parameters to be optimised
lb = [];
ub = [];
% % Initial guess
P0 = [14.796, 13.1203, -0.00135557, 1.16194, 0.00449364, -0.0115607, 24.6598, -3.65873, -4.61654];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'combined case: $F_z$ = $F_{z0}$ , $\gamma=0$'; 
fitting.textFileModel = 'tables/LateralModel_41.txt';
fitting.textFileOutput= 'tables/LateralOut_41.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FY(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);

%% STEP 4.2 Fitting combined case - variable $F_z$ , $\gamma=0$
fittingPars = {'rVy2'};

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = intersectTableData(VX, GAMMA_00);

% % Define limits  for parameters to be optimised
lb = [];
ub = [];
% % Initial guess
P0 = [0.1];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'combined case: variable $F_z$ , $\gamma=0$'; 
fitting.textFileModel = 'tables/LateralModel_42.txt';
fitting.textFileOutput= 'tables/LateralOut_42.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FY(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);


%% STEP 4.3 Fitting combined case
fittingPars = {'rVy3'};

% Intersect tables to obtain specific sub-datasets
[TDataSub, ~] = VX;

% % Define limits  for parameters to be optimised
lb = [];
ub = [];
% % Initial guess
P0 = [0];

% Fitting randomizer settings
fitting.Randomizer_Active = false;
fitting.Randomizer_Niter = 5;

% Specify data for table/report
fitting.textDescription = 'Combined case'; 
fitting.textFileModel = 'tables/LateralModel_43.txt';
fitting.textFileOutput= 'tables/LateralOut_43.txt';

% Run optimization algorithm
[tyre_data] = fit_MF96_FY(fittingPars, P0, lb, ub, TDataSub, tyre_data, fitting);