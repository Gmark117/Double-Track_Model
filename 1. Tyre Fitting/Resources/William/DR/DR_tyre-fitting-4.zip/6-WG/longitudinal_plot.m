%% Plot figures that are suggested on Lecture-02-5-DCVR-Tyre

% Setup
close all
currentFolder = strcat('figures/Fx/',wheel,'/','VX_',vxSelected);
mkdir(currentFolder);

colors = {'#0072BD','#D95319','#EDB120','#7E2F8E','#77AC30','#4DBEEE'};
% Nominal load
FZ_NOM = FZ_4500;
FZ_NOM_VAL = 4500;

%% a)
figure
hold on
titleText = strcat('Pure longitudinal slip --   $F_z:=$   ',' $F_{z0}$ ,',...
                                              ' $\alpha$ ',' $=0$ ,', ...
                                              ' $\gamma$ ',' $=0$ ');
title(titleText, 'interpreter', 'Latex');
xlabel('longitudinal slip $\kappa$','interpreter', 'Latex')
ylabel('$F_x$ (N)','interpreter', 'Latex')
[TDataSub, ~] = intersectTableData( ALPHA_00, GAMMA_00, VX, FZ_NOM);
KAPPA = TDataSub.KAPPA;
ALPHA = TDataSub.ALPHA;
GAMMA = TDataSub.GAMMA;
FZ = TDataSub.FZ;
FX = TDataSub.FX;   
[fx0_fit] = MF96_FX0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
plot(KAPPA, fx0_fit, 'DisplayName', 'Fitted');
plot(KAPPA, FX, 'DisplayName', 'Raw');
legend
grid on
exportgraphics(gcf,strcat(currentFolder,'/FX_figA.png'),'Resolution',ExportFigResolution)

%% b)
figure
hold on
titleText = strcat('Pure longitudinal slip at different vertical loads -- ');
title(titleText, 'interpreter', 'Latex');
xlabel('longitudinal slip $\kappa$','interpreter', 'Latex')
ylabel('$F_x$ (N)','interpreter', 'Latex')

vertLoads_TXT = [  2500,    4500,    6500,   10000];
vertLoads =     { FZ_2500, FZ_4500, FZ_6500, FZ_10000};

for i = 1:length(vertLoads)
    [TDataSub, ~] = intersectTableData( ALPHA_00, GAMMA_00, VX, vertLoads{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FX = TDataSub.FX;   
    [fx0_fit] = MF96_FX0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(KAPPA, fx0_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted Fz = ',num2str(vertLoads_TXT(i)), ' N'));
    plot(KAPPA, FX, '*', 'color', colors{i} , ...
        'DisplayName', strcat('Raw Fz = ',num2str(vertLoads_TXT(i)), ' N'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FX_figB.png'),'Resolution',ExportFigResolution)

%% c)
kappa_values = linspace(min(table.KAPPA),max(table.KAPPA),1000);
alpha_values = deg2rad([  0,        2.5,       5.0,      7.5,      10.0]);

figure
hold on
titleText = strcat('Weighting function G$_{x\alpha}$ as a function of $\kappa$ -- ', ...
                                            ' $F_z:=$   ',' $F_{z0}$ ,',...
                                            ' $\gamma$ ',' $=0$ ,');                                        
title(titleText, 'interpreter', 'Latex');
xlabel('longitudinal slip $\kappa$','interpreter', 'Latex')
ylabel('G$_{x\alpha}$','interpreter', 'Latex')

for i = 1:length(alpha_values)
    gxa_fit = [];
    for k = 1:length(kappa_values)
        [Gxa, Gyk, SVyk] = MF96_FXcomb_coeffs(kappa_values(k), alpha_values(i), 0, FZ_NOM_VAL, tyre_data);
        gxa_fit = [gxa_fit, Gxa];
    end
    plot(kappa_values, gxa_fit, 'color', colors{i} ,...
        'DisplayName', strcat('$\alpha = $ ',num2str(alpha_values(i)), ' deg'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FX_figC.png'),'Resolution',ExportFigResolution)

%% d)
figure
hold on
titleText = strcat('Pure longitudinal slip at different cambers -- ', ...
                    ' $F_z=$   ',' $F_{z0}$ ,',...
                    ' $\alpha$ ',' $=0$');   
title(titleText, 'interpreter', 'Latex');
xlabel('longitudinal slip $\kappa$','interpreter', 'Latex')
ylabel('$F_x$ (N)','interpreter', 'Latex')

camber_TXT =     [  0,    2.5,    5, ];
camber_ANGLES =  { GAMMA_00, GAMMA_25, GAMMA_50};

for i = 1:length(camber_ANGLES)
    [TDataSub, ~] = intersectTableData( ALPHA_00, FZ_NOM, VX, camber_ANGLES{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FX = TDataSub.FX;   
    [fx0_fit] = MF96_FX0_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(KAPPA, fx0_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted $\gamma$ = ',num2str(camber_TXT(i)), ' deg'));
    plot(KAPPA, FX, 'o', 'color', colors{i} , ...
        'DisplayName', strcat('Raw $\gamma$ = ',num2str(camber_TXT(i)), ' deg'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FX_figD.png'),'Resolution',ExportFigResolution)

%% e)
figure
hold on
titleText = strcat('Combined longitudinal slip at variable slip angles -- ', ...
                    ' $F_{z} = $   ',' $ F_{z0}$ ,',...
                    ' $\gamma $ ',' $ =0$');   
title(titleText, 'interpreter', 'Latex');
xlabel('longitudinal slip $\kappa$','interpreter', 'Latex')
ylabel('$F_x$ (N)','interpreter', 'Latex')

sideslip_TXT =     [  0,   5 ,    10  ];
sideslip_ANGLES =  { ALPHA_00, ALPHA_50, ALPHA_100};

for i = 1:length(sideslip_ANGLES)
    [TDataSub, ~] = intersectTableData(GAMMA_00, FZ_NOM, VX, sideslip_ANGLES{i});
    KAPPA = TDataSub.KAPPA;
    ALPHA = TDataSub.ALPHA;
    GAMMA = TDataSub.GAMMA;
    FZ = TDataSub.FZ;
    FX = TDataSub.FX;   
    [fx_fit] = MF96_FX_vec(KAPPA, ALPHA , GAMMA, FZ, tyre_data);
    plot(KAPPA, fx_fit, 'color', colors{i} ,...
        'DisplayName', strcat('Fitted $\alpha$ = ',num2str(sideslip_TXT(i)), ' deg'));
    plot(KAPPA, FX, '.', 'color', colors{i} , ...
        'DisplayName', strcat('Raw $\alpha$ = ',num2str(sideslip_TXT(i)), ' deg'));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FX_figE.png'),'Resolution',ExportFigResolution)

%% f)
kappa_values = [0, 0.1, 0.2, 0.5, 0.8, 1];
alpha_values = (linspace(min(table.ALPHA),max(table.ALPHA),100));

figure
hold on
titleText = strcat('Weighting function G$_{x\alpha}$ as a function of $\alpha$ --', ...
                                            ' $F_z:=$   ',' $F_{z0}$ ,',...
                                            ' $\gamma$ ',' $=0$ ,');                                        
title(titleText, 'interpreter', 'Latex');
xlabel('side slip angle $\alpha$ (deg)','interpreter', 'Latex')
ylabel('G$_{x\alpha}$','interpreter', 'Latex')

for i = 1:length(kappa_values)
    gxa_fit = [];
    for k = 1:length(alpha_values)
        [Gxa, Gyk, SVyk] = MF96_FXcomb_coeffs(kappa_values(i), alpha_values(k), 0, FZ_NOM_VAL , tyre_data);
        gxa_fit = [gxa_fit, Gxa];
    end
    plot(rad2deg(alpha_values), gxa_fit, 'color', colors{i} ,...
        'DisplayName', strcat('$\kappa = $ ',num2str(kappa_values(i))));
end
legend('location','southeast')
grid on
exportgraphics(gcf,strcat(currentFolder,'/FX_figF.png'),'Resolution',ExportFigResolution)