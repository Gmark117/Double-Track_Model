%% Create subtables in which some parameter is kept at a constant value

% Extract points at constant slip ratio
KAPPA_tol = 0.005;
KAPPA_00  = table( 0.00 - KAPPA_tol < table.KAPPA & table.KAPPA <  0.00 + KAPPA_tol, : );
KAPPA_05  = table( 0.05 - KAPPA_tol < table.KAPPA & table.KAPPA <  0.05 + KAPPA_tol, : );
KAPPA_10  = table( 0.10 - KAPPA_tol < table.KAPPA & table.KAPPA <  0.10 + KAPPA_tol, : );
KAPPA_15  = table( 0.15 - KAPPA_tol < table.KAPPA & table.KAPPA <  0.15 + KAPPA_tol, : );
KAPPA_20  = table( 0.20 - KAPPA_tol < table.KAPPA & table.KAPPA <  0.20 + KAPPA_tol, : );
disp(['KAPPA -- #pts. subtables/#pts = ', ...
     num2str(height([KAPPA_00; KAPPA_05; KAPPA_10; KAPPA_15; KAPPA_20])), ...
     '/', num2str(height(table))]);
 
% Extract points at constant side slip
ALPHA_tol = 0.005;
ALPHA_00  = table( 0.0  * pi/180 - ALPHA_tol < table.ALPHA & table.ALPHA <  0.0  * pi/180 + ALPHA_tol, : );
ALPHA_25  = table( 2.5  * pi/180 - ALPHA_tol < table.ALPHA & table.ALPHA <  2.5  * pi/180 + ALPHA_tol, : );
ALPHA_50  = table( 5.0  * pi/180 - ALPHA_tol < table.ALPHA & table.ALPHA <  5.0  * pi/180 + ALPHA_tol, : );
ALPHA_75  = table( 7.5  * pi/180 - ALPHA_tol < table.ALPHA & table.ALPHA <  7.5  * pi/180 + ALPHA_tol, : );
ALPHA_100 = table( 10.0 * pi/180 - ALPHA_tol < table.ALPHA & table.ALPHA <  10.0 * pi/180 + ALPHA_tol, : );
disp(['ALPHA -- #pts. subtables/#pts = ', ...
     num2str(height([ALPHA_00; ALPHA_25; ALPHA_50; ALPHA_75; ALPHA_100])), ...
     '/', num2str(height(table))]);
 
% Extract points at constant vertical load
FZ_tol    = 250.0;
FZ_100    = table(  100  -FZ_tol < table.FZ & table.FZ <  100  + FZ_tol, : );
FZ_1000   = table(  1000 -FZ_tol < table.FZ & table.FZ < 1000  + FZ_tol, : );
FZ_2500   = table(  2500 -FZ_tol < table.FZ & table.FZ < 2500  + FZ_tol, : );
FZ_4500   = table(  4500 -FZ_tol < table.FZ & table.FZ < 4500  + FZ_tol, : );
FZ_6500   = table(  6500 -FZ_tol < table.FZ & table.FZ < 6500  + FZ_tol, : );
FZ_8500   = table(  8500 -FZ_tol < table.FZ & table.FZ < 8500  + FZ_tol, : );
FZ_10000  = table(  10000-FZ_tol < table.FZ & table.FZ < 10000 + FZ_tol, : );
disp(['FZ -- #pts. subtables/#pts = ', ...
     num2str(height([FZ_100; FZ_1000; FZ_2500; FZ_4500; FZ_6500; FZ_8500; FZ_10000])), ...
     '/', num2str(height(table))]);
 
% Extract points at constant inclination angle
GAMMA_tol = 0.1*pi/180;
GAMMA_00  = table( 0.0*pi/180-GAMMA_tol < table.GAMMA & table.GAMMA < 0.0*pi/180+GAMMA_tol, : );
GAMMA_25  = table( 2.5*pi/180-GAMMA_tol < table.GAMMA & table.GAMMA < 2.5*pi/180+GAMMA_tol, : );
GAMMA_50  = table( 5.0*pi/180-GAMMA_tol < table.GAMMA & table.GAMMA < 5.0*pi/180+GAMMA_tol, : );
disp(['GAMMA -- #pts. subtables/#pts = ', ...
     num2str(height([GAMMA_00; GAMMA_25; GAMMA_50])), '/', num2str(height(table))]);

% Extract points at constant road speed
VX_tol = 0.5;
VX_05  = table( 5.0  - VX_tol < table.VX & table.VX < 5.0  + VX_tol, : );
VX_20  = table( 20.0 - VX_tol < table.VX & table.VX < 20.0 + VX_tol, : );
VX_45  = table( 45.0 - VX_tol < table.VX & table.VX < 45.0 + VX_tol, : );
VX_90  = table( 90.0 - VX_tol < table.VX & table.VX < 90.0 + VX_tol, : );
disp(['VX -- #pts. subtables/#pts = ', ...
     num2str(height([VX_05; VX_20; VX_45; VX_90])), '/', num2str(height(table))]);